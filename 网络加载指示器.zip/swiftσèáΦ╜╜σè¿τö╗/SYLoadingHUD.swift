//
//  SYProgressHUD.swift
//  NewETreatment
//
//  Created by 杨晨 on 2018/9/27.
//  Copyright © 2018 ShineYang. All rights reserved.
//

import UIKit

let green = UIColor.init(red: 44/255.0, green: 189/255.0, blue: 145/255.0, alpha: 1.0)


class SYLoadingHUD: UIView {

    var link:CADisplayLink!
    var animationLayer:CAShapeLayer!
    var startAngle:CGFloat?
    var endAngle:CGFloat = 0{
        didSet{
            
        }
    }
    var progress:CGFloat = 0{
        didSet{
            
        }
    }
    let lineWidth:CGFloat = 4.0
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addOwnViews()
    }
    override func addOwnViews() {
        animationLayer = CAShapeLayer()
        animationLayer.bounds = CGRect(x: 0, y: 0, width: 60, height: 60)
        animationLayer.position = CGPoint(x: self.bounds.size.width/2.0, y: self.bounds.size.height/2.0)
        
        animationLayer.fillColor = UIColor.clear.cgColor
        animationLayer.strokeColor = green.cgColor
        animationLayer.lineWidth = lineWidth
        animationLayer.lineCap = kCALineCapRound
        layer.addSublayer(animationLayer)
        
        link =  CADisplayLink(target: self, selector: #selector(displayLinkAction))
        link.add(to: RunLoop.main, forMode: .defaultRunLoopMode)
        link.isPaused = true
    }
    @objc func displayLinkAction(){
        progress += speed()
        if progress >= 1 {
            progress = 0
        }
        updateAnimationLayer()
        
    }
    func updateAnimationLayer(){
        startAngle = -CGFloat.pi/2
        endAngle = -CGFloat.pi/2 + progress * CGFloat.pi * 2
        if endAngle > CGFloat.pi {
            let progress1:CGFloat = 1 - (1 - progress)/0.25
            startAngle = -CGFloat.pi/2 + progress1 * CGFloat.pi * 2
        }
        let radius = animationLayer.bounds.size.width/2 - lineWidth/2
        let centerX = animationLayer.bounds.size.width/2.0
        let centerY = animationLayer.bounds.size.height/2.0
        let path = UIBezierPath(arcCenter: CGPoint(x: centerX, y: centerY), radius: radius, startAngle: startAngle!, endAngle: endAngle, clockwise: true)
        path.lineCapStyle = .round
        animationLayer.path = path.cgPath
  
    }
    func speed() ->CGFloat{
        if endAngle > CGFloat.pi {
            return 0.3/60.0
        }
        return 2/60.0
    }
    func hide(){
        link.isPaused = true
        progress = 0
    }
    func start(){
        link.isPaused = false
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @discardableResult class func showIn(view:UIView) -> SYLoadingHUD{
        let hud = SYLoadingHUD(frame: view.bounds)
        hud.start()
        view.addSubview(hud)
        return hud
    }
    @discardableResult class func hideIn(view:UIView) ->SYLoadingHUD{
        var hud:SYLoadingHUD?
        for  subView in view.subviews {
            if subView is SYLoadingHUD{
                let lodingHUD = subView as!SYLoadingHUD
                lodingHUD.hide()
                lodingHUD.removeFromSuperview()
                hud = lodingHUD
                
            }
        }
        return hud ?? SYLoadingHUD(frame: view.bounds)
        
    }
    
}


