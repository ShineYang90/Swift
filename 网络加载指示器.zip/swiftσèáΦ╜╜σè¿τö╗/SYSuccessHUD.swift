//
//  SYSuccessHUD.swift
//  NewETreatment
//
//  Created by 杨晨 on 2018/9/28.
//  Copyright © 2018 ShineYang. All rights reserved.
//

import UIKit

fileprivate let greenColor = UIColor.init(red: 44/255.0, green: 189/255.0, blue: 145/255.0, alpha: 1.0)

class SYSuccessHUD: UIView,CAAnimationDelegate {
    
    let lineWidth = 4.0
    let circleDuriation = 0.5
    let checkDuration = 0.2
    
    var animationLayer:CALayer!
    

    override init(frame: CGRect) {
        super.init(frame: frame)
        addOwnViews()
    }
    override func addOwnViews() {
        animationLayer = CALayer()
        animationLayer.bounds = CGRect(x: 0, y: 0, width: 60, height: 60)
        animationLayer.position = CGPoint(x: self.bounds.size.width/2, y: self.bounds.size.height/2)
        layer.addSublayer(animationLayer)
    }
    func circleAnimation(){
        
        let circleLayer = CAShapeLayer()
        circleLayer.frame = animationLayer.bounds
        animationLayer.addSublayer(circleLayer)
        circleLayer.fillColor = UIColor.clear.cgColor
        circleLayer.strokeColor = greenColor.cgColor
        circleLayer.lineWidth = CGFloat(lineWidth)
        circleLayer.lineCap = kCALineCapRound
        
        let linesWidth:CGFloat = 5.0
        let radius = animationLayer.bounds.size.width/2.0 - linesWidth / 2.0
        let path = UIBezierPath(arcCenter: circleLayer.position, radius: radius, startAngle: -(CGFloat.pi / 2), endAngle: CGFloat.pi * 3 / 2, clockwise: true)
        circleLayer.path = path.cgPath
        
        let circleAnimation = CABasicAnimation(keyPath: "strokeEnd")
        circleAnimation.duration = circleDuriation
        circleAnimation.toValue = 1.0
        circleAnimation.fromValue = 0.0
        circleAnimation.delegate = self
        circleAnimation.setValue("circleAnimation", forKey: "animationName")
        circleLayer.add(circleAnimation, forKey: nil)
        
        
        
    }
    //画对号
    func checkAnimation(){
        let checkFrom = animationLayer.frame.size.width
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: checkFrom * 2.7 / 10, y: checkFrom * 5.4 / 10))
        path.addLine(to: CGPoint(x: checkFrom * 4.5 / 10, y: checkFrom * 7 / 10))
        path.addLine(to: CGPoint(x: checkFrom * 7.8 / 10, y: checkFrom * 3.8 / 10))
        
        let checkLayer = CAShapeLayer()
        checkLayer.path = path.cgPath
        checkLayer.fillColor = UIColor.clear.cgColor
        checkLayer.strokeColor = greenColor.cgColor
        checkLayer.lineWidth = CGFloat(lineWidth)
        checkLayer.lineCap = kCALineCapRound
        checkLayer.lineJoin = kCALineJoinRound
        animationLayer.addSublayer(checkLayer)
        
        let checkAnimation = CABasicAnimation(keyPath: "strokeEnd")
        checkAnimation.duration = checkDuration
        checkAnimation.fromValue = 0.0
        checkAnimation.toValue = 1.0
        checkAnimation.delegate = self
        checkAnimation.setValue("checkAnimation", forKey: "animationName")
        checkLayer.add(checkAnimation, forKey: nil)
        
    }
    func hide(){
        for layer in animationLayer!.sublayers! {
             _ = layer.removeAllAnimations
        }
    }
    func start(){
        circleAnimation()
        DispatchQueue.main.asyncAfter(deadline: .now()+0.5 * circleDuriation, execute:
            {
             self.checkAnimation()
           
        })
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @discardableResult class func showIn(view:UIView) -> SYSuccessHUD {
        hideIn(view: view)
        let hud = SYSuccessHUD(frame: view.bounds)
        hud.start()
        view.addSubview(hud)
        return hud
    }
    @discardableResult class func hideIn(view:UIView) -> SYSuccessHUD{
        var hud:SYSuccessHUD?
        for subView in view.subviews {
            if subView is SYSuccessHUD{
                let subview = subView as!SYSuccessHUD
                subview.hide()
                subview.removeFromSuperview()
                hud = subview
            }
        }
        return hud ?? SYSuccessHUD(frame: view.bounds)
    }
}
